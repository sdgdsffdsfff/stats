DELIMITER //
CREATE PROCEDURE e()
BEGIN
	DECLARE time_v DATETIME;
	DECLARE match_type_v VARCHAR(32);
	DECLARE attack_type_v VARCHAR(32);
	DECLARE ip_v CHAR(15);
	DECLARE rule_id_v INT;
	DECLARE event VARCHAR(32);
	DECLARE done BOOLEAN DEFAULT FALSE;
	DECLARE log_info_cursor CURSOR FOR SELECT time,TRIM(match_type),TRIM(attack_type),ip,rule_id FROM log_info WHERE time BETWEEN DATE_SUB(NOW(),INTERVAL 1 MONTH) AND NOW();
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=TRUE;
	OPEN log_info_cursor;
	read_loop:LOOP
		IF done THEN 
			LEAVE read_loop;
		END IF;
		FETCH log_info_cursor INTO time_v,match_type_v,attack_type_v,ip_v,rule_id_v; 
		IF STRCMP(attack_type_v,'-') <> 0 THEN
			SET event = CONCAT('MODSEC_ALERT_EVENT_',SUBSTRING(attack_type_v,8));
			INSERT INTO tst values(time_v,event,ip_v,rule_id_v); 
		ELSE
			SET event = CONCAT('MODSEC_ALERT_EVENT_',SUBSTRING(match_type_v,7));
			INSERT INTO tst values(time_v,event,ip_v,rule_id_v); 
		END IF;
	END LOOP;
	CLOSE log_info_cursor;
END
//
DELIMITER ;
