DELIMITER //
CREATE PROCEDURE getTop(IN now DATETIME)
BEGIN
	-- event_log_info join event_times
	DECLARE done BOOLEAN DEFAULT FALSE;
	DECLARE e VARCHAR(32);
	DECLARE c CURSOR FOR SELECT a.event FROM event_log_info a INNER JOIN event_times b ON a.event=b.event AND (a.time BETWEEN DATE_SUB(now,INTERVAL 1 MINUTE) AND now) AND (b.time BETWEEN DATE_SUB(now,INTERVAL 1 MINUTE) AND now);
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=TRUE; 
	OPEN C;
	read_loop:LOOP
		IF done THEN
			LEAVE read_loop;
		END IF;
		FETCH c INTO e;  
		select e;
	END LOOP;
END
//
DELIMITER ;
