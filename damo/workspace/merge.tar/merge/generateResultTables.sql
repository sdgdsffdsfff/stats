DELIMITER //
CREATE PROCEDURE generateResultTables(IN now DATETIME,IN span INT)
BEGIN
	-- event times
	DELETE FROM event_times WHERE time BETWEEN DATE_SUB(now,INTERVAL '0 0:span:0' DAY_SECOND) AND DATE_SUB(now,INTERVAL '0 0:0:0' DAY_SECOND);
	INSERT INTO event_times SELECT * FROM (SELECT now) times,(SELECT event,COUNT(event) AS eventtimes FROM event_log_info WHERE time BETWEEN DATE_SUB(now,INTERVAL 20 HOUR) AND now GROUP BY event ORDER BY COUNT(event) DESC LIMIT 5) event_counts;  
	
	-- event ip iptimes 
	-- DELETE FROM event_ip_iptimes WHERE time BETWEEN DATE_SUB(now,INTERVAL '31 0:0:10' DAY_SECOND) AND DATE_SUB(now,INTERVAL 31 DAY);
	-- SELECT * FROM (SELECT now) times,(SELECT a.event,ip,COUNT(ip) AS iptimes FROM event_log_info a INNER JOIN event_times b ON a.event=b.event GROUP BY a.event,ip ORDER BY iptimes DESC) tmp;
	-- INSERT INTO event_ip_iptimes SELECT * FROM (SELECT * FROM (SELECT now) times,(SELECT a.event,ip,COUNT(ip) AS iptimes FROM event_log_info a INNER JOIN event_times b ON a.event=b.event GROUP BY a.event,ip ORDER BY iptimes DESC) tmp) da WHERE 2 > (SELECT COUNT(*) FROM da WHERE event=da.event AND iptimes > da.iptimes) ORDER BY da.event,da.iptimes DESC;
	-- SELECT * FROM (SELECT * FROM (SELECT now) times,(SELECT a.event,ip,COUNT(ip) AS iptimes FROM event_log_info a INNER JOIN event_times b ON a.event=b.event GROUP BY a.event,ip ORDER BY iptimes DESC) tmp) AS da WHERE 2 > (SELECT COUNT(*) FROM da WHERE event=da.event AND iptimes > da.iptimes) ORDER BY da.event,da.iptimes DESC;
	-- CREATE OR REPLACE VIEW view_for_fetch_data AS SELECT a.event,b.ip,COUNT(b.ip) AS iptimes FROM event_times a LEFT JOIN event_log_info b ON a.event=b.event WHERE b.time BETWEEN DATE_SUB(now,INTERVAL 10 HOUR) AND now GROUP BY a.event,b.ip ORDER BY a.event,iptimes DESC;
	-- INSERT INTO event_ip_iptimes SELECT * FROM (SELECT now) times,(SELECT * FROM view_for_fetch_data v WHERE 2 > (SELECT COUNT(*) FROM view_for_fetch_data WHERE event=v.event AND iptimes > v.iptimes) ORDER BY v.event,v.iptimes DESC) t;
END
//
DELIMITER ;
